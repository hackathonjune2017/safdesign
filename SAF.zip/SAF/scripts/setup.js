'use strict';
const db = require('@arangodb').db;
var collections = ['customer', 'snapshot','forms'];

collections.forEach(function(collection){
if (!db._collection(collection)) {
  db._createDocumentCollection(collection);
}
});

var edgeCollections = ['customer_edge', 'customer_snapshot_edge','snapshot_forms_edge','customer_latestform_edge'];

edgeCollections.forEach(function(edgeCollection){
if (!db._collection(edgeCollection)) {
  db._createEdgeCollection(edgeCollection);
}
});

