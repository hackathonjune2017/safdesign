
const createRouter = require('@arangodb/foxx/router');
const router = createRouter();

module.context.use(router);
const joi=require('joi');

const db = require('@arangodb').db;
const errors = require('@arangodb').errors;
const foxxColl = db._collection('customer');
const DOC_NOT_FOUND = errors.ERROR_ARANGO_DOCUMENT_NOT_FOUND.code;

// Create SAF Service
router.post('/createSAF/:clientId', function (req, res) {
const clientId=req.pathParams.clientId;
console.info('createSAF clientId '+clientId);  


const client_partyQuery="for cust in client_party_edge filter cust._from=='customer/"+clientId+"'  RETURN cust";
const client_partyResult=db._query(client_partyQuery).toArray();

console.info("createSAF "+JSON.stringify(client_partyResult));

const ticketColl = db._collection('ticket');
const ticketId = ticketColl.count()+2;
const ticketJSON ={_key:'tckt_'+ticketId,'ticketId':ticketId,'review_type':'New','status':'inProgress','creationtDate':new Date().toISOString()}
console.info('createSAF ticketJSON '+ticketJSON);  
ticketColl.save(ticketJSON);

const snapshotColl = db._collection('snapshot');
const snapshotId = snapshotColl.count()+2;
const snapshotJSON ={_key:'snpt_'+snapshotId,'snapshotId':snapshotId,'ticketId':ticketId,'cd_review_type':'NEW','creationtDate':new Date().toISOString()}
console.info('createSAF snapshotJSON '+snapshotJSON);  
snapshotColl.save(snapshotJSON);

const formColl = db._collection('forms');
const safFromJSON ={'questionnaire':{'question 1':'answer1','question 2':'answer2'},'type':'SAF','creationtDate':new Date().toISOString()}
const plsFromJSON ={'questionnaire':{'question 1':'answer1','question 2':'answer2'},'type':'PLS','creationtDate':new Date().toISOString()}
const pls1FromJSON ={'questionnaire':{'question 1':'answer1','question 2':'answer2'},'type':'PLS','creationtDate':new Date().toISOString()}

const safFormResult=formColl.save(safFromJSON);
const plsFormResult=formColl.save(plsFromJSON);
const pls1FormResult=formColl.save(pls1FromJSON);

console.info('createsaf safform'+JSON.stringify(safFormResult));
console.info('createsaf plsform'+JSON.stringify(plsFormResult));
console.info('createsaf pls1form'+JSON.stringify(pls1FormResult));


const auditColl = db._collection('audit');
const auditJSON ={'snapshotId':snapshotId,'ticketId':ticketId,'reviewer':'I645580',
                  'action':'claim','status':'inProgress','stage':'Compose stage','creationtDate':new Date().toISOString()}
console.info('createSAF auditJSON '+auditJSON+' collection '+auditColl);  

var auditJSONResult = auditColl.save(auditJSON);


db._collection('customer_ticket_edge').save(
  {
    _from:'customer/'+clientId,
    _to:'ticket/'+ticketJSON._key
  }
);

db._collection('ticket_snapshot_edge').save(
  {
    _from:'ticket/'+ticketJSON._key,
    _to:'snapshot/'+snapshotJSON._key
  }
);

const snapshot_forms_edge = db._collection("snapshot_forms_edge");
snapshot_forms_edge.save(
       {
        '_from':'snapshot/' + snapshotJSON._key,
        '_to' : 'forms/' +safFormResult._key ,
        'relation':'SAF'
       }
    );
snapshot_forms_edge.save(
       {
        '_from':'snapshot/' + snapshotJSON._key,
        '_to' : 'forms/' +plsFormResult._key ,
        'relation':'PLS'
       }
    );

db._collection("ticket_latestStage_edge").save(
  {
    _from:'ticket/'+ticketJSON._key,
    '_to' : 'audit/'+auditJSONResult._key ,
  }
);

db._collection("ticket_audit_edge").save(
  {
    _from:'ticket/'+ticketJSON._key,
    '_to':'audit/'+auditJSONResult._key ,
  }
);

db._collection("form_customer_edge").save(
  {
    _from:'forms/'+safFormResult._key,
    '_to':'customer/'+clientId ,
     'relation': 'Submitted by'

  }
);

db._collection("form_customer_edge").save(
  {
    _from:'forms/'+plsFormResult._key,
    '_to':client_partyResult[0]._to ,
    'relation': 'Submitted by'

  }
);
if(client_partyResult.length == 2){
db._collection("form_customer_edge").save(
  {
    _from:'forms/'+pls1FormResult._key,
    '_to':client_partyResult[1]._to ,
    'relation': 'Submitted by'
  }
);

snapshot_forms_edge.save(
       {
        '_from':'snapshot/' + snapshotJSON._key,
        '_to' : 'forms/' +pls1FormResult._key ,
        'relation':'PLS'
       }
    );

}


  res.send('ticket '+ticketId);
})
.pathParam('clientId', joi.string().required(), 'Key of the customer.')
.response(['text/plain'], 'Return is snapshotId.')
.summary('Create SAF')
.description('create SAF');



// Review Ticket Service
router.post('/reviewTicket/', function (req, res) {
   const auditJSON = req.body;
   console.info('review ticketId ' + JSON.stringify(auditJSON, null, 4));

   const ticketId = auditJSON.ticketId;

   const ticketQuery = "for t in ticket filter t.ticketId==" + ticketId + " RETURN t";
      console.info('review ticketQuery ' + ticketQuery);

   const ticketJSON = db._query(ticketQuery).toArray()[0];

   const auditColl = db._collection('audit');
   auditJSON.creationtDate=new Date().toISOString();
   console.info('Review auditJSON ' + JSON.stringify(auditJSON, null, 4));

   var auditJSONResult = auditColl.save(auditJSON);

   console.info('Review auditJSONResult ' + JSON.stringify(auditJSONResult, null, 4));

   console.info('Review ticketJSON ' + JSON.stringify(ticketJSON, null, 4));

   const auditQuery = "for audit in ticket_latestStage_edge filter audit._from=='ticket/" + ticketJSON._key + "' REMOVE audit in ticket_latestStage_edge LET removed = OLD RETURN removed";
   db._query(auditQuery).toArray()[0];

   db._collection("ticket_latestStage_edge").save(
     {
         _from: 'ticket/' + ticketJSON._key,
         '_to': 'audit/' + auditJSONResult._key,
     }
   );

   db._collection("ticket_audit_edge").save(
    {
        _from: 'ticket/' + ticketJSON._key,
        '_to': 'audit/' + auditJSONResult._key,
    }
  );


   res.send('ticketId ' + JSON.stringify(ticketJSON, null, 4));
})
.body('{"snapshotId":"snapshotId","ticketId":"ticketId","reviewer":"I645580","action":"submit","status":"completed","stage":"Review stage"}')
.response(['text/plain'], 'Return is Status')
.summary('Review Ticket')
.description('Review Ticket');




// approveSAF Service
router.post('/approveSAF/', function (req, res) {
const approveSAFJSON=req.body;
console.info('approve ticketId '+JSON.stringify(approveSAFJSON, null, 4));  

const ticketId=approveSAFJSON.ticketId;

const ticketQuery="for t in ticket filter t.ticketId=="+ticketId+" REMOVE t in ticket LET removed = OLD RETURN removed";
ticketJSON=db._query(ticketQuery).toArray()[0];
console.info('approve get ticketJSON '+JSON.stringify(ticketJSON, null, 4));  
ticketJSON.status='Approved';
ticketJSON.endDate=new Date().toISOString();

const ticketColl = db._collection('ticket');
console.info('approve ticketJSON '+JSON.stringify(ticketJSON, null, 4));  
ticketColl.save(ticketJSON);


const auditColl = db._collection('audit');
const auditJSON ={ 'ticketId':ticketId,'reviewer':'I645590',
                  'action':'Approved','status':'Completed','stage':'SM stage','creationtDate':new Date().toISOString()}
console.info('approve auditJSON '+JSON.stringify(auditJSON, null, 4));  

var auditJSONResult = auditColl.save(auditJSON);


const auditQuery="for audit in ticket_latestStage_edge filter audit._from=='ticket/"+ticketJSON._key+"' REMOVE audit in ticket_latestStage_edge LET removed = OLD RETURN removed";
auditQueryResult=db._query(auditQuery).toArray();

db._collection("ticket_latestStage_edge").save(
  {
    _from:'ticket/'+ticketJSON._key,
    '_to' : 'audit/'+auditJSONResult._key ,
  }
);

 db._collection("ticket_audit_edge").save(
  {
    _from:'ticket/'+ticketJSON._key,
    '_to':'audit/'+auditJSONResult._key ,
  }
);

custFormQuery = "FOR snapshot IN ANY 'ticket/"+ticketJSON._key+"' ticket_snapshot_edge "+
" OPTIONS {bfs: true, uniqueVertices: 'global'} "+
" FOR forms IN ANY snapshot._id snapshot_forms_edge "+
" OPTIONS {bfs: true, uniqueVertices: 'global'}"+
" FOR custForm IN  form_customer_edge"+
" filter custForm._from==forms._id"+
" RETURN custForm";

console.info("custFormQuery" +custFormQuery);

custFormQueryResult=db._query(custFormQuery).toArray();

console.info("custFormQueryResult" +JSON.stringify(custFormQueryResult));

custFormQueryResult.forEach(function (pair) {
  
  custDeleteFormQuery="for custDeleteForm in customer_latestform_edge filter custDeleteForm._from=='"+pair._to+"' REMOVE custDeleteForm in customer_latestform_edge"
  db._query(custDeleteFormQuery);

  db._collection("customer_latestform_edge").save(
  {
    _from:pair._to,
    '_to':pair._from,
    'relation':'Latest Approved'
  }
);
   
});




  res.send('ticketId '+JSON.stringify(ticketJSON, null, 4));
})
.body('{"ticketId":"43434", "action":"approve" , "comments":"comments343"}', 'Entry to store in the collection.')
.response(['text/plain'], 'Return is snapshotId.')
.summary('Approve SAF')
.description('Approve SAF');



// View Suitability Service
router.get('/ViewSuitability/:clientId', function (req, res) {

const clientId=req.pathParams.clientId;
console.info("ViewSuitability "+clientId);
var query ="FOR ticket IN ANY 'customer/"+clientId+"' customer_ticket_edge "+
"OPTIONS {bfs: true, uniqueVertices: 'global'} "+ 
"FOR snapshot IN ANY ticket._id ticket_snapshot_edge "+
"OPTIONS {bfs: true, uniqueVertices: 'global'} "+
"FOR forms IN ANY snapshot._id snapshot_forms_edge "+
"OPTIONS {bfs: true, uniqueVertices: 'global'}"+
"RETURN {snapshotId:snapshot.snapshotId,"+
"ticketId:snapshot.ticketId,"+
"cd_review_type:snapshot.cd_review_type,forms: forms}";
console.info(" query "+query);
var result =db._query(query).toArray();
console.info(" query result "+result);
res.send(result);
})
.pathParam('clientId', joi.string().required(), 'Key of the customer.')
.response(joi.object().required(), 'Displayed View Suitability.')
.summary('View Suitability')
.description('View Suitability');




// Get All Parties
router.get('/parties/:clientId', function (req, res) {
const custkey=req.pathParams.clientId;
console.info("key "+custkey);
var params = {'custkey' :custkey}
var query =" FOR X IN ANY 'customer/" + custkey + "'" + " client_party_edge OPTIONS {bfs: true, uniqueVertices: 'global'} RETURN X._id"
console.info(" query "+query);
var result =db._query(query).toArray();
console.info(" query result "+result);

res.send(result);
})
.pathParam('clientId', joi.string().required(), 'Key of the customer.')
.response(joi.object().required(), 'Entry stored in the client_party_edsge.')
.summary('Retrieve all parties')
.description('Retrieves all parties from the "client_party_edge" collection by customer id.');




// Get All ticket 
router.get('/tickets/:clientId', function (req, res) {
const custkey=req.pathParams.clientId;
console.info("key "+custkey);
var params = {'custkey' :custkey}
var query = " FOR X IN ANY 'customer/" + custkey + "'" + " customer_ticket_edge OPTIONS {bfs: true, uniqueVertices: 'global'} RETURN X"
console.info(" query "+query);
var result =db._query(query).toArray();
console.info(" query result "+result);

res.send(result);
})
.pathParam('clientId', joi.string().required(), 'Key of the customer.')
.response(joi.object().required(), 'Entry stored in the client_ticket_edge.')
.summary('Retrieve all tickets')
.description('Retrieves all tickets from the "client_tickte_edge" collection by customer id.');

